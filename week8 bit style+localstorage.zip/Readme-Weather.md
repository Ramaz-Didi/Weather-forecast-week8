Weather Dashboard

script file organizing link between 2 API's, from first its gat latitude and longitude of the place, to which weather information need to be displayed.![Alt text](assets/Screenshots/Screenshot%202023-01-31%20232006.jpg)![Alt text](assets/Screenshots/Screenshot%202023-01-31%20232133.jpg)